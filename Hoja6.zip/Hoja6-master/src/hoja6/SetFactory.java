/*
Autores: Xavier Cifuentes- 13316
         Pablo de leon - 13227
Fecha: 31/08/16
 */
 

package hoja6;

import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.LinkedHashSet;


public class SetFactory {
    
    public Set GetSet (Integer op)
    {
        if (op == 1)
            return new HashSet();
        if (op == 2)
            return new TreeSet();
        if (op == 2)
            return new LinkedHashSet();
        else 
            return null;
    }
    
    
}
